import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class User {
    private String userID;
    private String userName;
    private boolean hasVoted;

    public User(String userID, String userName) {
        this.userID = userID;
        this.userName = userName;
        this.hasVoted = false;
    }

    public String getUserID() {
        return userID;
    }

    public String getUserName() {
        return userName;
    }

    public boolean hasVoted() {
        return hasVoted;
    }

    public void castVote() {
        if (!hasVoted) {
            hasVoted = true;
        } else {
            System.out.println("You have already voted!");
        }
    }
}

class Candidate {
    private String candidateID;
    private String candidateName;
    private int voteCount;

    public Candidate(String candidateID, String candidateName) {
        this.candidateID = candidateID;
        this.candidateName = candidateName;
        this.voteCount = 0;
    }

    public String getCandidateID() {
        return candidateID;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public int getVoteCount() {
        return voteCount;
    }

    public void incrementVotes() {
        voteCount++;
    }
}

class VotingSystem {
    private List<User> users;
    private List<Candidate> candidates;

    public VotingSystem() {
        users = new ArrayList<>();
        candidates = new ArrayList<>();
    }

    public void addUser(User user) {
        users.add(user);
    }

    public void addCandidate(Candidate candidate) {
        candidates.add(candidate);
    }

    public void castVote(User user, Candidate candidate) {
        if (user.hasVoted()) {
            System.out.println("User has already voted.");
        } else {
            user.castVote();
            candidate.incrementVotes();
            System.out.println(user.getUserName() + " voted for " + candidate.getCandidateName());
        }
    }

    public void showResults() {
        System.out.println("Voting Results:");
        for (Candidate candidate : candidates) {
            System.out.println(candidate.getCandidateName() + ": " + candidate.getVoteCount() + " votes");
        }
    }

    public List<User> getUsers() {
        return users;
    }

    public List<Candidate> getCandidates() {
        return candidates;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        VotingSystem votingSystem = new VotingSystem();

        // Add candidates
        System.out.println("Enter the number of candidates:");
        int numCandidates = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        for (int i = 1; i <= numCandidates; i++) {
            System.out.println("Enter candidate " + i + " name:");
            String candidateName = scanner.nextLine();
            Candidate candidate = new Candidate("C00" + i, candidateName);
            votingSystem.addCandidate(candidate);
        }

        // Add users
        System.out.println("Enter the number of users:");
        int numUsers = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        for (int i = 1; i <= numUsers; i++) {
            System.out.println("Enter user " + i + " name:");
            String userName = scanner.nextLine();
            User user = new User("U00" + i, userName);
            votingSystem.addUser(user);
        }

        // Voting process
        for (User user : votingSystem.getUsers()) {
            System.out.println(user.getUserName() + ", it's your turn to vote!");

            // Show candidates
            System.out.println("Choose a candidate to vote for:");
            for (int i = 0; i < votingSystem.getCandidates().size(); i++) {
                System.out.println((i + 1) + ". " + votingSystem.getCandidates().get(i).getCandidateName());
            }

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            // Cast the vote
            if (choice >= 1 && choice <= votingSystem.getCandidates().size()) {
                Candidate selectedCandidate = votingSystem.getCandidates().get(choice - 1);
                votingSystem.castVote(user, selectedCandidate);
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }

        // Show results
        votingSystem.showResults();

        scanner.close();
    }
}
